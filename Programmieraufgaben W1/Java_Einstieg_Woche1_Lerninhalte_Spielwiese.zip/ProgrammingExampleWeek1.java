public class ProgrammingExampleWeek1 {

	public static void main(final String[] args) {
		ExampleClass example = new ExampleClass();
		example.text = "Das Ergebnis lautet: ";
		System.out.println(example.combinedAttributes());
		System.out.println("Summe: " + example.getSum());
	}
}
