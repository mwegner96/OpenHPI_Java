class ExampleClass {
	int zahl = 2;
	double fließkommazahl = 1.2;
	String text;
	
	String combinedAttributes(){
		return "Alle Attribute dieses Objekts hintereinander: " + text  + zahl + fließkommazahl;
	}

    double getSum(){
        return (zahl + fließkommazahl); 
    }
}
