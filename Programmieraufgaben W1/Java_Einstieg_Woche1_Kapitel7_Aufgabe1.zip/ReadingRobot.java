class ReadingRobot {

    String task = "Ich lese codierte Nachrichten.";

	void sayTask() {
		System.out.println(task);
	}

    String getTask() {
        return task;
    }
}
