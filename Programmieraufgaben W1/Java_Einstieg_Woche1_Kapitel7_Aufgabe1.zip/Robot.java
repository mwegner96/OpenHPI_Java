class Robot {

    String task = "Ich infiltriere die Geheimbasis und suche Paco.";
    
    void sayTask() {
		System.out.println(task);
	}

	String getTask() {
		return task;
	}
}