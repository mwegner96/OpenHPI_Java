class Story {
	public static void main(String[] args) {
		Robot robin = new Robot();
		robin.sayHello();
        Robot alex = new Robot();
        alex.sayWelcome();
	}
}