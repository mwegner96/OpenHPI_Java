class Office {
    PasswordGenerator pg = new PasswordGenerator();
    String password = new String();
    
    void printPassword(){
        password = pg.getPassword();
        System.out.println(password);
    }

}
