class Story {
	public static void main(String[] args) {
		Office office = new Office();
		office.printPassword();
	}
}
