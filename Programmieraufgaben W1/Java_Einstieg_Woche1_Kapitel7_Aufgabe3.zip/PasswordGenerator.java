class PasswordGenerator {
    
    Password password = new Password();

	public String getPassword() {
		return password.getPassValue();
	}
}
