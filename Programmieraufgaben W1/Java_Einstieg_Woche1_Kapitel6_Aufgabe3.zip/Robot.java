class Robot {
    int age = 1;
    
   public void sayAge(){
       System.out.println("Ich bin " + age + " Jahr alt.");
   }
}
