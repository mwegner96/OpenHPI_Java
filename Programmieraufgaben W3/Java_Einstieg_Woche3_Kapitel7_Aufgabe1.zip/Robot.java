abstract class Robot {

    abstract void saySomething();
}