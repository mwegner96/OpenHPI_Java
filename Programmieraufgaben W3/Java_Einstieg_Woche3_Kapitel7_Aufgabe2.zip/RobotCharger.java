class RobotCharger {

    void chargeRobot(Robot rob){
        rob.batteryRuntime += 7;
    }
}
