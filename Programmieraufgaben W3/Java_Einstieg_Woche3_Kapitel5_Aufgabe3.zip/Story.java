class Story {

	public static void main(String[] args) {
		Parrot paco = new Parrot();
		paco.move();
		paco.speak();
		paco.speak("Ich kann viele verschiedene Sätze sagen");
	}
}