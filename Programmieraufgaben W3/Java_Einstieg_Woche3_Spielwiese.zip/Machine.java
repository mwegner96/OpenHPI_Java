public abstract class Machine {
	public abstract void act();
}