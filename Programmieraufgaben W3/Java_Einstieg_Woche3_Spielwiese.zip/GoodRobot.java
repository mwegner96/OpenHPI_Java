public class GoodRobot extends Robot {

	@Override
	public void move() {
		System.out.println("GoodRobot: Please, let me pass.");
	}

	@Override
	public void act() {
		System.out.println("GoodRobot: Help the little grandma to get over the street.");
	}

}
