public class OldRobot {
	int internalStorageSize = 0;

	void setStorage(int storageSize) {
		this.internalStorageSize = storageSize;
	}
}