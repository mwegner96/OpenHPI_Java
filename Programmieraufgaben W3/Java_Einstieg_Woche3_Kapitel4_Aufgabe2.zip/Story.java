class Story {

	public static void main(String[] args) {
        Robot ronja = new Robot();
        ronja.setStorage(1250);
        System.out.println(ronja.internalStorageSize);
        System.out.println(ronja.additionalStorageSize);
    }

}
