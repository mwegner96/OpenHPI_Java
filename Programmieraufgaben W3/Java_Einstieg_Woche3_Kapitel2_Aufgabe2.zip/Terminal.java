class Terminal {
    
    public void hackRobot(TestRobot test){
        System.out.println(test.hasFirewall);
        System.out.println(test.id);
        System.out.println(test.numberOfProcessorCores);
    }
}
