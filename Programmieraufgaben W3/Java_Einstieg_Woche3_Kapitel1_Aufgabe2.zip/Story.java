class Story {
	public static void main(String[] args) {
		DetectiveRobot ronja = new DetectiveRobot();
		ronja.speak();

	}
}
