public class MathRobot {

    int addition(int a, int b){
        return a+b;
    }
    
    int addition(int a, int b, int c){
        return a+b+c;
    }
    
    double addition(double a, double b){
        return a+b;
    }
    
    double addition(double a, double b, double c){
        return a+b+c;
    }
}
