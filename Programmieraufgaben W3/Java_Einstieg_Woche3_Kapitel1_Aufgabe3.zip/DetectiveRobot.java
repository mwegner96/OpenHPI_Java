class DetectiveRobot extends Robot {
    int spareBatteryRuntime;
    
    public DetectiveRobot(){
        this.spareBatteryRuntime = 5;
    }

   public int giveTotalBatteryRuntime(){
       return (giveBatteryRuntime() + this.spareBatteryRuntime);
   }
}
