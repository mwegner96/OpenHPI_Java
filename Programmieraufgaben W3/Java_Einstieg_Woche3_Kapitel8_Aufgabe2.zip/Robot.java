abstract class Robot {

	private int batteryRuntime;

	Robot(int batteryRuntime) {
		this.batteryRuntime = batteryRuntime;
	}
	
	public int getBatteryRuntime() {
	    return batteryRuntime;
	}

}
