class DecodeRobot {

    void tap(String in, int a){
        for(int i = 0; i < a; i++){
            System.out.println(in);
        }
    }
    
    void tap(String in){
        tap(in, 3);
    }
}
