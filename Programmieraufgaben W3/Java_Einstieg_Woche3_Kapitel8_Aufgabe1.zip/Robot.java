class Robot {

	String task;
	
	Robot() {
		this("Duke helfen");
	}

	Robot(String task) {
		this.task = task;
	}

}
