public class Story {
	
	public static void main(String[] args) {
		Robot robin = new Robot();
		robin.setTask("Zimmer Aufräumen");
		robin.work();
		robin.setTask("Müll rausbringen");
		robin.work();
	}
	
}