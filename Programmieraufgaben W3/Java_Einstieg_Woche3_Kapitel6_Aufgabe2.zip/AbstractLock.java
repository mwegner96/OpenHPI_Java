abstract public class AbstractLock {
    int secretNumber;
    String secretWord;
    int numberOfAttempts;

    abstract boolean openWithSecretNumber(int number, int attempt);
    
	abstract boolean openWithSecretWord(String word);
}

