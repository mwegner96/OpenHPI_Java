public class Robot implements Flyable{

    public void fly() {
        System.out.println("Ich fliege mit meinen Raketen!");
    }

}

