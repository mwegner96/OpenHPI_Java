public class MathRobot {
	public double div(String a, String b) {
		// Füge hier deinen Code ein
		return Double.parseDouble(a) / Double.parseDouble(b);
	}
}
