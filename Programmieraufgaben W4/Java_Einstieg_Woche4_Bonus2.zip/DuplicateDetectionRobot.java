import java.util.ArrayList;
import java.util.HashSet;

public class DuplicateDetectionRobot {

	// implementiere hier die Methode
	void printDuplicates(ArrayList<String> list1, ArrayList<String> list2) {
        for(String content1 : list1){
            for(String content2 : list2){
                if (content1.equals(content2)){
                    System.out.println(content2);
                }
            }
        }
    }
}
