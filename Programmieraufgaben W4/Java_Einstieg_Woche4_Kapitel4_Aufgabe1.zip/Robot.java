import java.util.ArrayList;

public class Robot {

    void giveAccessCodes(ArrayList<String> in){
        for (String str : in) {
            System.out.println(str);
        }
    }

}
