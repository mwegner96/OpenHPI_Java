public class Calculator {

	int calculateSum(int[] numbers) {
		// Berechne hier die Summe aller Zahlen mit einer foreach Schleife und gib sie zurück:
		int sum = 0;
        for (int n : numbers) {
            sum += n;
        }
        return sum;
	}

	double calculateMean(int[] numbers) {
		double sum = calculateSum(numbers);
		int i = 0;
		// Berechne hier das Arithmetische Mittel und gib es zurück:
        for (int n : numbers) {
            i++;
        }
        
        return sum / i;
	}
}
