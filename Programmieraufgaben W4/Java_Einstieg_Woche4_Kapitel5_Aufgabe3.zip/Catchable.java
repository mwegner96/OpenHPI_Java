interface Catchable {

    void tryToCatch(boolean in);

}
