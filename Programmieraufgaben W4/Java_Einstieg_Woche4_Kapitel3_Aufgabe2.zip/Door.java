import java.util.HashMap;

class Door {

    HashMap<String, AccessCode> doorCodes = new HashMap<>();

	void addDoorKey(String in, AccessCode code) {
	   doorCodes.put(in, code);
	}
	
	void useCode(String in){
	    doorCodes.get(in).setNumberOfTimesUsed(doorCodes.get(in).getNumberOfTimesUsed() + 1);

        if (doorCodes.get(in).getNumberOfTimesUsed() > 2) {
            System.out.println("Schlüssel nicht mehr gültig");
            doorCodes.get(in).setValid(false);
        } else {
            doorCodes.get(in).setValid(true);
            System.out.println("Schlüssel gültig");
        }
	}
	
	public HashMap<String, AccessCode> getDoorCodes() {
		return doorCodes;
	}
}
