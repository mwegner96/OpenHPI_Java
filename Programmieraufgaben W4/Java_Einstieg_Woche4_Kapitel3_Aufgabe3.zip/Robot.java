import java.util.ArrayList;
import java.util.HashMap;

class Robot {

	ArrayList<AccessCode> usedAccessCodes = new ArrayList<>();
	ArrayList<AccessCode> unusedAccessCodes = new ArrayList<>();
	HashMap<String, AccessCode> codeHashMap = new HashMap<>();

    public void saveCodes(ArrayList<AccessCode> list){
        
         for (AccessCode it : list) { 
             if (it.getUsed() == true) {
                usedAccessCodes.add(it); 
             } else {
                unusedAccessCodes.add(it); 
             }
         }
    }
    
    void buildHashMap() {
        for (AccessCode it : usedAccessCodes) { 
            codeHashMap.put("used", it);   
        }
        
        for (AccessCode it : unusedAccessCodes) { 
            codeHashMap.put("unused", it);   
        }
    }
}
