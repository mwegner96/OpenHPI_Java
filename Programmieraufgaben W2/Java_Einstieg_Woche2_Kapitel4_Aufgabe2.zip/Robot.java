class Robot {
    String sentence = "Ich kann sprechen!";
    RandomNumber rand = new RandomNumber();
    
    
    void speak() {
        int number = rand.giveNumber();
        speakSeveralTimes(number);
    }
    
    void speakSeveralTimes(int in) {
        for (int i = 0; i < in; i++) {
            System.out.println(sentence);
        }
    }

}
