class Robot {
    void testNumber(int in){
        if ((in%2) == 0) {
            System.out.println("Die Zahl ist durch 2 teilbar!");
        } else {
            System.out.println("Die Zahl ist nicht durch 2 teilbar!");
        }
        
    }
}
