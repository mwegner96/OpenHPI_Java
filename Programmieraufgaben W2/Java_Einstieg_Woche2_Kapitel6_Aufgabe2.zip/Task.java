class Task {
    String position;

    Task(String input){
        this.position = input;
    }
}
