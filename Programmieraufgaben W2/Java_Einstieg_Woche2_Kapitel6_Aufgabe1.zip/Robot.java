class Robot {
    int batteryRuntime;

    Robot() {
        batteryRuntime = 5;
    }

}
