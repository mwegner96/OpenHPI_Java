class Story {
	public static void main(String[] args) {
		GPS myGPS = new GPS();
		String myPassword = new String();
		String coordinates = new String();
		coordinates = "breite"; //hoehe  laenge
		
		myPassword = myGPS.getCoordinates(coordinates);
		System.out.println(myPassword);
	}
}
