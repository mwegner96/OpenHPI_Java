class RandomNumberGreaterTen {

    RandomNumber rand = new RandomNumber();
    int number = 0;

    int greaterTen() {
        while (number <= 10) {
        number = rand.giveNumber();
    } 
    return number;
    }
}
