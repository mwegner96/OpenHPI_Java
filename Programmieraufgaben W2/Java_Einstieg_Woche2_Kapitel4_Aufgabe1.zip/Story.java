class Story {

   public static void main(String args[]) {
        Robot robin = new Robot();
        // robin soll bis 20 zählen. 
        // Verändere hier die Zahl, wenn du andere obere Zählgrenzen ausprobieren willst.
        robin.countTo(20);
    }

}
