class Robot {

	int batteryRuntime = 5;

	boolean isBatteryRuntimeLow() {
		if (batteryRuntime < 2) {
		    return true;
            
		} else {
		    //Ergänze in der nachfolgenden Zeile einen Rückgabewert
            return false;
    	}
    }
}
