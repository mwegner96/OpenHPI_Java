class Robot {
    void speakTwice(String in){
        for (int i = 1; i<=2; i++) {
            System.out.println(in);
        }
    }
}
