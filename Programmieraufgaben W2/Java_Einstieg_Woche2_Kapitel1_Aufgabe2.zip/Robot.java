class Robot {
    String completeName(String name, String art){
        return name + " " + art;
    }
}
