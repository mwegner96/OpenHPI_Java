public class ReplacementPart {
    String color;
    String type;
    int size;
    
    // schreibe den Konstruktor hier hin
    ReplacementPart(String type, String color, int size){
        this.color = color;
        this.type = type;
        this.size = size;
    }
}